package com.adrian.a3em1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView tarja;
    private ImageView logo;
    private Button oficina, teste, social;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tarja = findViewById(R.id.tarja);
        logo = findViewById(R.id.logo);
        oficina = findViewById(R.id.oficina);
        teste = findViewById(R.id.teste);
        social = findViewById(R.id.social);

        oficina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirMapa();
            }
        });

        teste.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirTeste();
            }
        });

        social.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirSocial();
            }
        });


    }

    private void abrirMapa() {
        Intent janelaM = new Intent(this, Mapa.class);
        startActivity(janelaM);
    }

    private void abrirTeste() {
        Intent janelaT = new Intent(this, TesteDrive.class);
        startActivity(janelaT);
    }

    private void abrirSocial() {
        Intent janelaS = new Intent(this, Social.class);
        startActivity(janelaS);
    }




}