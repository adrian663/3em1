package com.adrian.a3em1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Social extends AppCompatActivity {

    Button instagram, facebook, youtube, voltar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_social);

        voltar = findViewById(R.id.voltar);
        instagram = findViewById(R.id.instagram);
        facebook = findViewById(R.id.facebook);
        youtube = findViewById(R.id.youtube);

        instagram.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirInstagram();
            }
        });

        facebook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirFacebook();
            }
        });

        youtube.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirYoutube();
            }
        });

        voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirVoltar();
            }
        });

    }

    public void abrirInstagram(){
        Intent janelaI = new Intent(Intent.ACTION_VIEW, Uri.parse("https://instagram.com/noturno_dosguri_ofc?igshid=15qdc4ujl2e5j"));
        startActivity(janelaI);
    }

    public void abrirFacebook(){
        Intent janelaF = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.facebook.com/Amantesdas2Rodas"));
        startActivity(janelaF);
    }

    public void abrirYoutube(){
        Intent janelaY = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/user/lu9004"));
        startActivity(janelaY);
    }

    private void abrirVoltar(){
        Intent janelaV = new Intent(this, MainActivity.class);
        startActivity(janelaV);
    }

}