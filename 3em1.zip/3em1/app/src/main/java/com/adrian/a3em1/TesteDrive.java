package com.adrian.a3em1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class TesteDrive extends AppCompatActivity implements SensorEventListener {

    private Sensor proximidade;
    private SensorManager medir;
    private Button voltar;
    private TextView visual;
    MediaPlayer mp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teste_drive);

        medir = (SensorManager) this.getSystemService(SENSOR_SERVICE);
        proximidade= medir.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        voltar = findViewById(R.id.voltar);
        visual = findViewById(R.id.visual);
        mp = MediaPlayer.create(this, R.raw.ronco);


        voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirVoltar();
            }
        });

    }

    @Override
    protected void onResume() {
        medir.registerListener(this, proximidade, SensorManager. SENSOR_DELAY_NORMAL);
        super.onResume();
    }

    @Override
    protected void onPause() {
        medir.unregisterListener(this, proximidade);
        super.onPause();
    }


    @Override
    public void onSensorChanged(SensorEvent event) {
        if(event.values[0] == 0 ){
            mp.start();
            visual.setText("Acelerando!");
        }
        else{
            visual.setText(" ");
        }

    }





    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }

    private void abrirVoltar(){
        Intent janela = new Intent(this, MainActivity.class);
        startActivity(janela);
    }

}